#ifndef GESTOR_H
#define GESTOR_H

typedef struct t
{
    char *nome_tarefa;
    int prioridade;
    struct t *next;
} tarefa;

void inserir_tarefa(tarefa **lista, char *nome_tarefa, int prioridade);
void imprimir_tarefas(tarefa *lista);
void listar_tarefas_com_prioridade_indicada(tarefa *lista, int prioridade);
void remover_tarefa(tarefa **lista, char *tarefa);
int readLineArguments(char **argVector, int vectorSize, char *buffer, int buffersize);

#endif