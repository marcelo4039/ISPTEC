#include <stdio.h>
#include <stdlib.h>
#include "gestor.h"
#include <locale.h>

_Bool presenca_de_espaco(char *string)
{
    while (*string)
    {
        if (*string == ' ')
        {
            return 1;
        }
        string++;
    }
    return 0;
}

int main()
{
    setlocale(LC_ALL, "Portuguese");
    tarefa *lista = NULL;
    int numArgs;
    char *argVector[100];
    char buffer[100] = "";

    while (1)
    {

        printf("\nDIGITE UM COMANDO POR FAVOR !\n");
        numArgs = readLineArguments(argVector, 100, buffer, sizeof(buffer));

        if (numArgs == -1)
        {
            printf("Erro ao ler entrada!\n");
            break;
        }

        if ((numArgs >= 3) && (strcmp(argVector[0], "new") == 0))
        {
            int prioridade = atoi(argVector[1]);
            char nome_tarefa[100] = {""};

            if (((prioridade == 0) && (strcmp(argVector[1], "0") != 0)) || (prioridade < 0) || (prioridade > 5))
            {
                printf("COMANDO INVALIDO!\n");
            }
            else
            {

                for (int i = 2; i <= numArgs - 1; i++)
                {
                    strcat(nome_tarefa, " ");
                    strcat(nome_tarefa, argVector[i]);
                }

                inserir_tarefa(&lista, nome_tarefa, prioridade);
            }
        }
        else if ((numArgs >= 2) && (strcmp(argVector[0], "list") == 0))
        {
            int prioridade = atoi(argVector[1]);

            if (((prioridade == 0) && (strcmp(argVector[1], "0") != 0) || (prioridade < 0) || (prioridade > 5)))
            {
                printf("COMANDO INVALIDO!\n");
            }
            else
            {
                listar_tarefas_com_prioridade_indicada(lista, prioridade);
            }
        }
        else if ((numArgs >= 2) && (strcmp(argVector[0], "complete") == 0))
        {
            char nome_tarefa[100] = {""};

            for (int i = 1; i <= numArgs - 1; i++)
            {
                strcat(nome_tarefa, " ");
                strcat(nome_tarefa, argVector[i]);
            }
            remover_tarefa(&lista, nome_tarefa);
        }
        else if ((numArgs == 1) && (strcmp(argVector[0], "exit") == 0)){
            break;
        }
        else
        {
            printf("COMANDO INVALIDO!\n");
        }
    }

    return 0;
}
